# PASS/BLOCKED فاز — قالب، امضا نشده

- phase / تاریخ / manager / coder / tester:
- host_SHA / firmware_SHA / dirty_diff_digest / dependency_lock:
- تصمیم‌های پنج دور طراحی و لینک sources:
- اصلاح‌های شماره‌دار و علت ریشه‌ای:

| requirement_id | test command | expected | actual | artifact path/hash | status |
|---|---|---|---|---|---|
| پر شود | فرمان واقعی | مقدار/رفتار | نتیجه واقعی | مسیر خام | PASS/FAIL/NOT_RUN/BLOCKED |

- مستقل از مهندسی: verdict علمی SUPPORTED/NOT_SUPPORTED/INCONCLUSIVE/NOT_TESTED:
- regression و test-order/cleanup:
- محدودیت bench/network/API واقعی:
- دو دور نقد کد و دو دور نقد نتیجه:
- گام بعد؛ قبل از آن چه شرطی لازم است:

هیچ سلول یا امضا از پیش PASS نیست. فاصلهٔ محلی تا CI یا hardware log توضیح داده شود.
