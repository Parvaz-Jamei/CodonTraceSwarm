# تحویل تیم میزبان و اتصال Genesis

این سند درخواست تغییر است، نه تغییر اعمال‌شده. پیش از PR کد موجود و شاخه‌های باز را جست‌وجو کنید؛ duplicate coordinator یا journal نسازید.

۱. mapping channel→input provider رسمی با schema، unit، transform version و generation boundary. timestamp دریافت، timestamp نمونه، sample_id=swarm/node/boot/seq و mapping digest ثبت. با ورودی ثابت و RNG یکسان، replay recorded inputs باید state/trajectory یکسان بدهد. دادهٔ live آینده روی نسل گذشته اثر نگذارد؛ تاریخچهٔ tick snapshot immutable باشد. ایرادهای MD قبلی history/alias و replay با این الزام مرتبط‌اند.
۲. link future: فعلاً فقط Wi-Fi. extension ترجیحاً negotiation روشن نسخهٔ قرارداد؛ legacy wifi=true فقط برای Wi-Fi واقعی. عدم تفسیر کلید اختیاری ناشناخته به‌عنوان تایید قابلیت. اترنت/سریال optional و خارج base release؛ serial CRC framing خود هویت/auth نیست، باید طول/timeout/resync/overlong/connection identity جدا تعریف شود.
۳. مشاهدهٔ بعد از فرمان: state pending/acknowledged/rejected/expired/boot_replaced و sample version واقعی. command ID کنونی cmd-N است؛ تداوم journal و restart host مهم است. برای reset journal ممکن است ID reuse شود؛ epoch/session extension یا سیاست reset boot پیش از دوباره‌کاری، طراحی و آزمون شود.
۴. pause/stop: runtime فعلی reading را reject و فرمان pending را cancel می‌کند؛ پروژهٔ simulation را با swarm acquisition یکی فرض نکنید. اگر جمع‌آوری هنگام pause لازم است، مسیر acquisition جدا با journal و lifecycle صریح اضافه شود؛ قانون موجود خاموش دور زده نشود. مشاهده/تحلیل تاریخی در همهٔ وضعیت‌ها فقط‌خواندنی کار کند.
۵. stream UI data از journal با pagination/downsampling نوع‌دار، نه snapshot history512 به‌عنوان کل run. extrema/event و invalid gap حفظ؛ hash input manifest مشترک کارت/گراف/analysis. تغییر sample shape در یک سری با descriptor version جدا.
۶. LLM ابزار خواندن state، انتخاب کانال/سید/window، ساخت chart spec با filter validated و diagnostics، تحلیل archived run؛ tokens/ACL و project scope. کنترل set_rate فقط عملیات تبلیغ‌شده و bounds؛ ابزار model update جدا. بدون مدل هم manual UI همان chart engine را صدا بزند.
۷. QD یک archive با descriptor **رفتار مشاهده‌شده** (event recall، latency، rate/bytes، recovery) نه parameter values صرف. candidates ارزیابی با mapping نسخه‌دار، bounded mutation، finite check و candidate immutable. این prerequisite ادعای policy evolution است.
۸. raw و پردازش و پارامتر و artifact و source SHA یک manifest واحد، schema نسخه‌دار، seeded RNG در مسیر شبیه‌سازی موتور؛ noise حقیقی حسگر seed نمی‌گیرد و در log ضبط می‌شود. SHA-chain بی‌کلید اثبات ضدجعل عمدی نیست؛ external anchor برای provenance بادوام.

هیچ dashboard یا MCU نباید world را مستقیم از callback تغییر دهد. روی نصب بدون swarm هم engine import/run درست و optional dependencies absent معتبر بماند.
