# قرارداد منابع و API

## انتخاب نسخه و حافظه

ESP32 هدف full reference release است. ESP8266 و بردهای Wi-Fi دیگر پس از build و bench سطح پشتیبانی می‌گیرند. Uno 2KB RAM را با 32 descriptor کامل و TLS یکسان فرض نکنید. pure core کوچک می‌تواند compile-only باشد؛ اگر همان هم اندازه‌گیری نشده `architectures=*` وعده داده نشود.

بودجهٔ هر profile شامل sizeof registry، descriptor storage، TX/RX، command queue، dedup cache، driver state، JSON، TLS peak و task stack است. ابتدا native `sizeof` و build map، سپس heap-minimum/stack high-water روی برد. 65536 سقف ورودی **میزبان** است، نه دستور تخصیص 64KB روی stack برد. hello کامل باید قبل از اتصال در اندازهٔ profile جا شود؛ کمبود ظرفیت باعث رد define/begin با توضیح می‌شود، نه truncate یا hello چندقسمتی مخفی. بیشینهٔ مستقل فیلدها تضمین اندازهٔ کل نیست.

پروفایل پیشنهادی اولیه و قابل تغییر پس از اندازه‌گیری: ESP32 با RX command=4096، TX message=8192، 8 کانال ساده، 8 فرمان queued و 32 dedup entry. این‌ها هدف مهندسی‌اند نه نتیجهٔ bench و نه همهٔ ترکیب‌های descriptor ممکن. full32 پروفایل جداست. waveform طول256 تنها با اندازه‌گیری bytes/latency و ceiling روشن. پروفایل کوچک فقط کانال‌های واقعاً قابل جاگیری.

ArduinoJson v7 پیش‌فرض allocation دارد؛ یکی را انتخاب و ثبت کنید: bounded writer/parser مستقل، v7 custom bounded allocator با تست exhaustion، یا v6 fixed document با pin و مسیر ارتقا. ورودی JSON ناقص/تکراری/بیش‌ازحد عمق باید reject شود؛ بسیاری parserها کلید تکراری را جایگزین می‌کنند، برای command این رفتار پذیرفته نیست. صفر allocation در مسیر steady-state هدف قابل سنجش است؛ کتابخانهٔ MQTT/TLS ممکن است allocation داشته باشد و نباید به آن تضمین مطلق تعمیم داد.

## API مفهومی، نه کد قابل کامپایل

- `define(ChannelSpec, SampleCallback, UserContext)` پیش از hello: deep ownership یا lifetime قراردادی؛ نگهداری pointer به stack موقت ممنوع.
- `begin(SessionConfig, Client&, ClockProvider&) -> Result` بدون loop بی‌پایان.
- `poll(MonotonicTime)`: یک بودجهٔ کار محدود، پردازش فرمان بیرون callback شبکه.
- `submit(Sample)` زمان اکتساب را حفظ می‌کند؛ seq را scheduler واحد می‌دهد.
- `health()` شمارنده‌های واقعی و ظرفیت/نسخه را به sketch می‌دهد؛ تغییر payload heartbeat فعلی `{}` ندهید. health روی metadata قانونی reading یا خروجی محلی/endpoint host نمایش داده شود.
- `end()` آزادسازی/close idempotent؛ `reconnect` همان boot؛ `reboot` nonce تازه و hello تازه.

`Result` خطاهای InvalidDescriptor, CapacityExceeded, ClockNotReady, NotConnected, DriverTimeout, CommandExpired, UnsupportedOperation را تفکیک کند. خطای ساخت descriptor قبل hello است؛ خطای نمونهٔ حسگر reading نامعتبر؛ شکست publish و افت شبکه با شمارنده است.

## عدد و متن

seq و UTC int64/uint64 bounded <=2^53-1، نه double و نه uint32 millis. bool به جای integer، NaN/Inf، unit mismatch، shape mismatch رد. واحد در code ASCII alias قابل‌ثبت و در UI نام استاندارد؛ تبدیل g→m/s² با ثابت مرجع و G→T با SI evidence خودکار قابل ارائه است؛ نیاز به کالیبراسیون آزمایشگاهی برای صرف تبدیل دقیق واحد نگذارید. در مقابل count→kg یا impedance→moisture مدل و شواهد واقعی می‌خواهد. `range` میزبان روی مقدار **بعد از normalization** اعمال می‌شود.

متن میزبان برحسب طول رشته بررسی می‌شود؛ firmware محدودیت bytes UTF-8 نیز دارد. پیشوند truncate نکنید. JSON escaping، Unicode مجاز، control character و round-trip عدد مرزی تست شود. روی AVR double ممکن است float32 باشد؛ tolerance و دقت را واقعی بنویسید، دادهٔ مرجع پُردقت از راه آن ادعا نکنید.
