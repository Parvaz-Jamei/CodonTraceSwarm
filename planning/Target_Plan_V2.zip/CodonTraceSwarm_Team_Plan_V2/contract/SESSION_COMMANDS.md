# قرارداد زمان، نشست و فرمان

## ساعت

ClockProvider هم UTC epoch-ms برای sample و command و هم monotonic برای scheduler می‌دهد. millis برای زمان‌بندی صحیح است، به‌جای UTC sample صحیح نیست. sync ناموفق => عدم ارسال reading؛ نامشخص‌بودن clock age/error در diagnostics اعلام شود. bootstrap برای NTP به broker وابسته نباشد؛ TLS گواهی معتبر و زمان معتبر می‌خواهد. UTC نمونه، زمان acquisition است، نه زمان خروج از صف.

NTP step-back نباید silent با clamp یا timestamp ساختگی پوشانده شود. پس از تشخیص jump ارسال reading را متوقف/صف کهنه را جدا و clock mapping را بازتنظیم کنید؛ restart measurement session با boot_id جدید راه محدود اولیه است و در journal توضیح واقعی session-reset ثبت شود. میزبان نیز backwards host UTC را رد می‌کند؛ تیم میزبان این وضعیت را در health/recovery مدیریت کند. UTC میلی‌ثانیه‌ای برای phase alignment دقیق میکروفون یا IMU سریع کافی نیست؛ waveform sample_period_us و monotonic acquisition و clock uncertainty لازم‌اند. sample_ms را شروع پنجره تعریف کنید. فریم حرارتی AMG8833 64 پیکسل spatial است، waveform زمانی با dt ساختگی نباشد؛ اگر shape2D فعلاً نیست با generic vector محدود یا 8 ردیف waveform با metadata spatial و visualization مستقل، بدون ادعای پایهٔ زمانی منتقل شود.

## نشست و ترتیب

boot_id از boot nonce معتبر یا counter پایدار دستگاه؛ صرف millis/UTC شناسهٔ تضمین‌شده نیست. client_id پایدار و منحصربه‌فرد دستگاه؛ duplicate-ID بروکر باعث قطع همدیگر می‌شود. seq بین hello/reading/heartbeat/reply مشترک و monotonic است. بعد از overflow، session جدید؛ در همان boot reset نکنید.

Reconnect همان boot است و hello بدون تغییر capability با seq بالاتر مجاز. پیش از چنین hello، صف قدیمی با seq پایین‌تر باید flush یا expired/drop ثبت شود؛ hello جدید نباید heartbeat را از reading عقب‌مانده جلو بیندازد. سیاست baseline ساده: هنگام disconnect publishing را متوقف، reconnect hello تازه و سپس فقط نمونهٔ تازه؛ تعداد loss با علت محفوظ. replay تاریخی از صف قدیمی با UTC جدید ممنوع. آرشیو اختیاری محلی مستقل برای پژوهش می‌تواند اصل timestamps را نگه دارد.

Heartbeat خالی حدود5s (با زمان‌سنج monotonic) در حالت ساعت و اتصال آماده؛ latest reading جای heartbeat را اگر میزبان alive بدانست می‌گیرد، ولی clock stale نباید با heartbeat برای داده trust بسازد. نرخ descriptor سقف واقعی است؛ پس از overload backpressure و drop counters، نه burst عقب‌افتادگی.

## فرمان

MQTT3.1.1 QoS1 duplicate دارد. callback advanced bytes/length را در صف bounded کپی می‌کند و بازمی‌گردد؛ publish/subscribe از همان callback ممنوع. حلقهٔ poll payload را parse و scope/topic/node/swarm/boot/schema/operation/params/created/expires را validate می‌کند. epoch درست شرط expiry است. موضوع retained پایین توسط backend یا broker ACL باید رد شود؛ اگر callback retain را عرضه نمی‌کند، ادعای تشخیص مستقیم ندهید و محدودیت و راه broker/patch backend را ثبت کنید.

Dedup key=(swarm_id,node_id,boot_id,command_id). همان key با params متفاوت reject؛ hash مخصوص byte canonicalizer روی برد را با digest Python یکسان فرض نکنید. cache مدت عمر فرمان+retry window و state را نگه دارد؛ هنگام ظرفیت کامل، فرمان جدید را بدون اثر با ok:false رد کنید و entry فعال را بیرون نیندازید. command expired/wrong boot روی دستگاه هیچ اثر ندارد. همان فرمان با delivery duplicate دوباره driver را صدا نمی‌زند؛ reply ذخیره‌شده را می‌توان retransmit کرد. میزبان فعلی reply دوم بعد acknowledged را reject می‌کند؛ این rejection نباید اثر دوم یا crash ایجاد کند. شبکهٔ QoS1 ضمانت exactly-once برنامه‌ای هنگام power loss نیست؛ برای sample/set_rate idempotent رفتار و مرز recovery تعریف شود.

sample: نام کانال قانونی، acquisition bounded، reading تازه و reply متناسب با نتیجه. تعریف ok=true یعنی sampling تمام شده/سیاست اعمال شده؛ PUBACK یا enqueue به تنهایی کافی نیست. set_rate: bounded hz، period attainable، نرخ واقعی با tolerance، نسخهٔ schedule در manifest؛ reset processing_version صرف نرخ در صورت بی‌تغییربودن preprocessing لازم نیست.

pipeline/capsule امروز روی میزبان فقط `{alpha,clip,event_threshold}` برای scalar و source_digest optional می‌پذیرد. این برنامه TinyML کامل نیست. ابتدا shadow میزبان؛ بعد پشتیبانی دقیق همین Pipeline و golden numeric vectors روی دستگاه؛ سپس فعال‌سازی با مجوز. مدل TFLite/درخت/NN/OTA به protocol extension جدا با model artifact hash، نوع ورودی، اندازه، امضا/اعتبار، compatibility و rollback نیاز دارد. تا آن extension merge نشده از capsule برای باینری دلخواه استفاده نکنید.
