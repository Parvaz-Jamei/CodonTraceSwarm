# حسگرهای generic و adapterهای واقعی

generic support یعنی مقدار قانونی با descriptor قانونی ingest می‌شود؛ driver support یعنی I/O قطعه انجام می‌شود؛ bench-tested یعنی برد واقعی آزمون شده؛ engine-integrated یعنی مقدار در مسیر رسمی نسل اثر دارد. این چهار وضعیت را یکی نکنید.

| خانواده | نمایش اولیه | قابلیت توسعهٔ مفید و شرط |
|---|---|---|
| محیطی BME/SHT/TMP/DS18 | دما، رطوبت، فشار با واحد driver | heater/warm-up/config و نرخ مستقل هر quantity ثبت |
| خازنی FDC1004 | pF مبدأ، F خروجی، signed raw24/CAPDAC/status | عدم CAPDAC دوباره، مرجع خازن مستقل، drift دما و تغذیه |
| رزونانسی FDC221x | Hz derived با مسیر clock دقیق | فریکانس→ظرفیت تنها با L و مدل و reference؛ FDC211 محدودیت API را حفظ کند |
| IMU/مغناطیس | vector با axes و coordinate_frame | quaternion derived 4-axis generic مجاز، scale/calibration/orientation ثبت |
| فاصله/ToF | mm و validity واقعی | timeout و out-of-range flag؛ sentinel را بدون datasheet/API قطعی تفسیر نکنید |
| نیرو/وزن HX711 | raw signed count | kg/N با tare، span، reference و model، نه حذف همیشگی واحد مفید |
| برق INA/ADS | V، shunt V، raw count | A/W با مقدار shunt و gain و کالیبراسیون/شواهد؛ energy با انتگرال جریان/ولتاژ و dt اندازه‌گیری‌شده |
| صوت/لرزش | waveform زمانی با sample_period_us | ring/DMA و timestamp ابتدا؛ spectrum derived با window/sample rate؛ dB با تعریف مرجع و پاسخ ابزار |
| تصویر/حرارتی | featureها/آرایهٔ spatial | protocol فعلی تصویر حجیم ندارد؛ descriptors spatial extension آینده؛ camera ممنوع مطلق نیست |
| آب/خاک/گاز | raw، proxy یا derived | pH/EC/moisture/ppm با calibration domain، دما، ageing، reference؛ eCO2 نام CO2 مستقیم نگیرد |
| موقعیت/GPS | lat/lon با validity fix | 0,0 واقعی با fix معتبر مجاز؛ صفر جعلی بدون fix نامعتبر؛ epoch/coordinate datum صریح |
| شمارش/RFID/تماس | scalar count، category، boolean | category ID دامنه و privacy; edge debounce version؛ RFID سنسور رخداد است نه عملگر |
| RTC | ClockProvider | خود RTC timestamp source است؛ channel اختیاری clock diagnostics، سنسور محیطی تلقی نشود |

شش درایور پایه BME280، SHT4x، INA219، VL53L0X، HX711، FDC1004 حفظ می‌شوند. جدول قطعات قبلی مرجع discovery است، ادعای tested نیست. SHT4x رطوبت و دما دارد، عبارت «همان BME280» نباید فشار برایش بسازد. کتابخانهٔ driver optional جدا و dependency license ثبت. هدف تست‌پذیر: driver sampling callback بدون MQTT و با deadline، clock acquisition، status اختصاصی و output unit/scale واقعی.

حد عمومی vector16/waveform256 و channels32 قانون wire است؛ ظرفیت profile ممکن است کمتر باشد. همهٔ حسگرهای جهان خودکار پشتیبانی نمی‌شوند؛ هر قطعهٔ سازگار از adapter generic با data type مناسب قابل اضافه‌کردن است؛ ماتریس latency/range و مدل فیزیکی محدودیت واقعی را مشخص می‌کند.

### FDC در ریپوی خود کاربر

`Parvaz-Jamei` کتابخانهٔ FDCxCapSense دارد؛ قبل از انتخاب driver نام/HEAD/API آن را از منبع واقعی قفل کنید، حدس از اسم قطعه کافی نیست. adapter میزبان فعلی valid فرکانس را نیازمند frefDivider>=1 می‌داند؛ گزارش قبلی نشان داد مسیر API با fref موثر ممکن است divider=0 بدهد. فاز۳ دو مسیر readFrequencyHz و readFrequencyHzFromRegisters را جدا با نسخهٔ دقیق و fixture واقعی بررسی کند؛ مقدار 1 جعلی وارد نکنید. توسعهٔ conversion_path نیازمند تغییر قراردادی میزبان است، نه field اضافهٔ مخفی.

ظرفیت wire و دادهٔ raw با مدل مترولوژی فرق دارند. direct در قرارداد به معنی دریافت مقدار instrument است، نه اثبات traceability آزمایشگاهی. uncertainty استاندارد بدون evidence و مدل انتشار ساخته نشود؛ missing uncertainty، zero uncertainty نیست.
