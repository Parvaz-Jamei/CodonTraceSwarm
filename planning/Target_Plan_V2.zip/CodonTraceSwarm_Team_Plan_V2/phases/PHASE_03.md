# فاز 03 — رجیستری کامل و driverهای پایه

## مدیر
SHA میزبان/کتابخانه، scope و blockerها را در checkpoint ثبت؛ پنج دور طراحی و منابع primary. خروج یا تغییر دامنه با تصمیم ثبت‌شده، نه رفع مانع با جعل قابلیت.

## کدر
define عمومی و Presets با source units، شش adapter اختیاری؛ FDCxCapSense واقعی pinned؛ callback deadline و ساخت error samples.

## قرارداد طراحی
sensor metadata/model و range در واحد normalized؛ waveform temporal/spatial تفاوت؛ table coupling با واحد؛ deterministic mock drivers و مسیر not-ready/timeout.

## تستر و معیار خروج
هر driver تست native mock و compile-example؛ حداقل FDC1004 و یک environmental sensor bench برای ادعای measured؛ generic هر5نوع ingest؛ source values و normalization exactly once؛ دو API frequency FDC221x مشخص.

## حملات لازم
read API failure بدون NaN/zero placeholder، raw24 signed edge، CAPDAC، notready/dataReady، high-rate deadline، license dependencies. بدون bench برچسب compiled-only بماند.

دو دور نقد پیش از آزمون و دو دور نقد نتیجه. هر معیار یک فرمان/آزمون/Artifact دارد. `templates/PASS_PHASE.md` پر شود؛ موارد اجرا‌نشده به‌صورت NOT_RUN/BLOCKED، نه PASS. تمام regressionهای فازهای قبلی اجرا شوند. برای هر ایراد شماره، ورودی، expected/actual و علت ثبت؛ رفع چندفایلی لازم مجاز. مدت آزمون عدد جادویی نیست؛ در soak خواسته‌شده نتایج منابع و acquisition workload واقعی هم ثبت شود.
