# فاز 04 — فرمان و اتصال موتور و پنل

## مدیر
SHA میزبان/کتابخانه، scope و blockerها را در checkpoint ثبت؛ پنج دور طراحی و منابع primary. خروج یا تغییر دامنه با تصمیم ثبت‌شده، نه رفع مانع با جعل قابلیت.

## کدر
CommandInbox/cache، sample/set_rate، trace generation input و replay در شاخهٔ میزبان، typed chart UI و کارت مستقل experiment.

## قرارداد طراحی
dedup + expiry + wrong boot، reply after effect، applied schedule trace؛ read-only analysis همهٔ وضعیت‌ها؛ تغییر موتور با PR جدا و protocol extension فقط با negotiation.

## تستر و معیار خروج
آزمون end-to-end دو node→coordinator→inputprovider→generation→journal→replay با disturbance ثابت؛ مقدار سنسور به خروجی واقعی اثر و frozen-input کنترل؛ pause/resume/stop/restart هر کارت مستقل؛ command duplicate یک effect؛ gap در SVG/plot حفظ.

## حملات لازم
callback world-mutation، history alias، stale descriptor، stopped read، chart category/vector خاموش حذف نشود، command-ID reuse و journal failure؛ دادهٔ archived نیز دیده شود.

دو دور نقد پیش از آزمون و دو دور نقد نتیجه. هر معیار یک فرمان/آزمون/Artifact دارد. `templates/PASS_PHASE.md` پر شود؛ موارد اجرا‌نشده به‌صورت NOT_RUN/BLOCKED، نه PASS. تمام regressionهای فازهای قبلی اجرا شوند. برای هر ایراد شماره، ورودی، expected/actual و علت ثبت؛ رفع چندفایلی لازم مجاز. مدت آزمون عدد جادویی نیست؛ در soak خواسته‌شده نتایج منابع و acquisition workload واقعی هم ثبت شود.
