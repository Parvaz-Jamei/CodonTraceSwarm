# فاز 02 — Wi-Fi و TLS و clock و صف

## مدیر
SHA میزبان/کتابخانه، scope و blockerها را در checkpoint ثبت؛ پنج دور طراحی و منابع primary. خروج یا تغییر دامنه با تصمیم ثبت‌شده، نه رفع مانع با جعل قابلیت.

## کدر
Session روی Client injected، ESP32 reference sketch، bounded inbox/outbox، reconnect/backoff، clock monitor، health counters.

## قرارداد طراحی
CA/hostname معتبر بدون setInsecure، clock-before-TLS، acquisition timestamp، mono deadlines، stable client ID، seq shared، reconnect queue/drop policy؛ callback فقط queue.

## تستر و معیار خروج
broker محلی واقعی با TLS و ACL دو node؛ hello/read/QoS1؛ قطع شبکه و broker restart؛ invalid certificate/wrong topic؛ jitter و UTC jump-forward/back، stale sample و backlog؛ نمودار throughput/memory. Hardware test هنوز اگر برد نیست BLOCKED است.

## حملات لازم
duplicate MQTT، queue full، oversized command، repeated disconnect، battery/supply reset؛ هیچ reading با UTC جعلی ingest نشود.

دو دور نقد پیش از آزمون و دو دور نقد نتیجه. هر معیار یک فرمان/آزمون/Artifact دارد. `templates/PASS_PHASE.md` پر شود؛ موارد اجرا‌نشده به‌صورت NOT_RUN/BLOCKED، نه PASS. تمام regressionهای فازهای قبلی اجرا شوند. برای هر ایراد شماره، ورودی، expected/actual و علت ثبت؛ رفع چندفایلی لازم مجاز. مدت آزمون عدد جادویی نیست؛ در soak خواسته‌شده نتایج منابع و acquisition workload واقعی هم ثبت شود.
