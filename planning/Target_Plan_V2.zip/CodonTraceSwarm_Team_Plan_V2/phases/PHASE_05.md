# فاز 05 — سیاست محدود و آزمایش علمی و release

## مدیر
SHA میزبان/کتابخانه، scope و blockerها را در checkpoint ثبت؛ پنج دور طراحی و منابع primary. خروج یا تغییر دامنه با تصمیم ثبت‌شده، نه رفع مانع با جعل قابلیت.

## کدر
pipeline فعلی bounded فقط پس از golden parity، shadow mode، یک RQ-S ازپیش‌ثبت‌شده، package/CI/installer و نسخهٔ واقعی.

## قرارداد طراحی
عدم تبلیغ NN/TinyML از capsule محدود؛ signed/model artifact مسیر آینده؛ baselines budget matched، independent reference و holdout؛ capability matrix و README صادقانه.

## تستر و معیار خروج
native+host+broker suites و حداقل overnight soak12h روی reference board برای اولین release کامل؛ memory growth/reset/drop quantiles با علت؛ نصب تمیز ArduinoCLI و وابستگی اختیاری absent؛ core موردادعا compile شود؛ dataset/manifests/hash/research verdict مستقل.

## حملات لازم
policy no-effect و negative-transfer، clock/network faults، incorrect capsule، regression همهٔ فازها؛ هیچ PASS research از count ثابت یا synthetic fixture ساخته نشود.

دو دور نقد پیش از آزمون و دو دور نقد نتیجه. هر معیار یک فرمان/آزمون/Artifact دارد. `templates/PASS_PHASE.md` پر شود؛ موارد اجرا‌نشده به‌صورت NOT_RUN/BLOCKED، نه PASS. تمام regressionهای فازهای قبلی اجرا شوند. برای هر ایراد شماره، ورودی، expected/actual و علت ثبت؛ رفع چندفایلی لازم مجاز. مدت آزمون عدد جادویی نیست؛ در soak خواسته‌شده نتایج منابع و acquisition workload واقعی هم ثبت شود.
