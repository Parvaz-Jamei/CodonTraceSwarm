# فاز 01 — قرارداد و core قابل آزمون

## مدیر
SHA میزبان/کتابخانه، scope و blockerها را در checkpoint ثبت؛ پنج دور طراحی و منابع primary. خروج یا تغییر دامنه با تصمیم ثبت‌شده، نه رفع مانع با جعل قابلیت.

## کدر
WireCodec، ChannelSpec، ClockProvider interface، profile ظرفیت، native tests، generator پیام C++ واقعی؛ بدون driver یا شبکهٔ واقعی.

## قرارداد طراحی
JSON integer64/bool/null، escaping و duplicate-key rejection در parser فرمان؛ lifecycle registry ownership؛ whole-message capacity، type/shape و schema. `library.properties` حداقلی زودتر مجاز است تا build واقعی شود.

## تستر و معیار خروج
fixtureهای C++ واقعی از decode/ingest میزبان pinned عبور کنند؛ raw fixture با status invalid/null، valid0، vector/boolean/category/waveform؛ negative/schema/overflow/size tests؛ native ASan/UBSan تا حد toolchain؛ اندازهٔ profile و memory map ثبت.

## حملات لازم
TX overflow، UTF8، unknown field، vector wrong shape، 33rdchannel، table extrapolation، reused pointer. baseline کنترل فقط SYNTHETIC است.

دو دور نقد پیش از آزمون و دو دور نقد نتیجه. هر معیار یک فرمان/آزمون/Artifact دارد. `templates/PASS_PHASE.md` پر شود؛ موارد اجرا‌نشده به‌صورت NOT_RUN/BLOCKED، نه PASS. تمام regressionهای فازهای قبلی اجرا شوند. برای هر ایراد شماره، ورودی، expected/actual و علت ثبت؛ رفع چندفایلی لازم مجاز. مدت آزمون عدد جادویی نیست؛ در soak خواسته‌شده نتایج منابع و acquisition workload واقعی هم ثبت شود.
