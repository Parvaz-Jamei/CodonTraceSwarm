# نتایج واقعی بررسی بسته — ۲۰۲۶-۱۰-۱۲

- کد میزبان در worktree جدا روی `74c7b3f15c2d093da03e392094814d63a4997c2c` خوانده شد؛ HEAD قدیمی checkout اصلی استفاده نشد. remote main نیز همین SHA بود.
- audit مستقل قرارداد: **۲۴ از ۲۴ چک مطابق رفتار موردانتظار**. این کنترل parser/coordinator است، نه آزمون محصول C++ ساخته‌نشده.
- regression دو فایل میزبان: **۷۰ پاس، ۱ skip**، ۷۱ مورد جمع‌آوری شد. فایل‌ها: `tests/test_swarm_protocol_runtime.py` و `tests/test_swarm_v5_contracts.py`. dependency اختیاری MQTT در محیط موجود نبود و یک مسیر SDK با skip عبور کرد؛ broker و TLS واقعی آزموده نشده‌اند.
- fixture اولیه hello در decode قبول، reading_invalid با UTC صفر در decode قبول و در ingest زنده stale رد؛ با UTC تازه null معتبر ingest شد. مقدار صفر با valid=true/status=ok دادهٔ معتبر است.
- تغییر processing_version در همان boot پذیرفته می‌شود. قرارداد اولیه در این مورد دقیق نبود؛ capability کانال و operations همچنان در همان boot ثابت‌اند.
- نمونهٔ دارای ۳۲ کانال با ۶۴ knot و متن‌های مجاز، **۷۸۹۹۶ بایت** شد و به‌درستی از سقف۶۵۵۳۶ میزبان عبور نکرد. هر فیلد به‌تنهایی bounded بودن کافی نیست. حداکثر ترکیب ظرفیت باید قبل از hello کنترل شود.
- انواع vector، waveform، boolean و category از مسیر ingest بررسی شدند؛ این پذیرش wire به معنی پشتیبانی فیلتر/درایور/نمودار همهٔ انواع نیست.

### بازتولید

```bash
# از محیطی که وابستگی‌های تست repo را دارد؛ REPO مسیر checkout دقیق میزبان است
PYTHONPATH="$REPO/src" python3 review/host_contract_audit.py > review/host_contract_audit.json
# از ریشهٔ repo pinned:
python3 -m pytest -o addopts='' -q tests/test_swarm_protocol_runtime.py tests/test_swarm_v5_contracts.py
```

هیچ فایل firmware در بستهٔ ورودی نبود و arduino-cli در این محیط موجود نبود؛ compile برد، bench sensor، load واقعی مدل، تست broker/TLS و soak را انجام‌شده معرفی نمی‌کنیم. `NOT_RUN` چنین آزمون‌هایی باید تیم را به اجرا برساند. این طرح محصول عملی و پژوهشی قابل ساخت را مشخص می‌کند، اما جای اندازه‌گیری آن را نمی‌گیرد.
