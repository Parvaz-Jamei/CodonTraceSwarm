"""Audit the supplied specification against a selected, unmodified Genesis tree.

This does NOT test Arduino firmware. Run with PYTHONPATH=<pinned-repo>/src.
"""
import copy
import json
from pathlib import Path

from codontrace.swarm.protocol import decode
from codontrace.swarm.runtime import SwarmCoordinator

HERE = Path(__file__).resolve().parents[1]
base = json.loads((HERE / 'original_reference/fixtures/hello_v2.json').read_text())
reading = json.loads((HERE / 'original_reference/fixtures/reading_invalid.json').read_text())
NOW = 1791763200000
results = []


def check(name, fn, expected='accept'):
    try:
        value = fn()
        actual = 'accept'
        detail = {'accepted': value.get('accepted', True)} if isinstance(value, dict) else str(value)
    except (ValueError, TypeError, KeyError) as exc:
        actual, detail = 'reject', str(exc)
    results.append({'name': name, 'expected': expected, 'actual': actual,
                    'passed': expected == actual, 'detail': detail})


def changed(obj, path, value):
    out = copy.deepcopy(obj)
    cur = out
    for p in path[:-1]:
        cur = cur[p]
    cur[path[-1]] = value
    return out


def ingest_pair(m, timestamp=NOW):
    s = SwarmCoordinator('lab')
    s.ingest(base, now_ms=NOW)
    return s.ingest(m, now_ms=timestamp)


fresh = changed(reading, ['payload', 'sample_ms'], NOW)
valid = copy.deepcopy(fresh)
valid['payload'].update(value=0, valid=True, status='ok')
check('hello_fixture_decode', lambda: decode(base))
check('invalid_fixture_decode_zero_timestamp', lambda: decode(reading))
check('invalid_fixture_ingest_stale', lambda: ingest_pair(reading), 'reject')
check('fresh_invalid_null_ingest', lambda: ingest_pair(fresh))
check('valid_zero_is_data', lambda: ingest_pair(valid))
for name, path, value in [
    ('wifi_integer', ['payload', 'wifi'], 1),
    ('wifi_false', ['payload', 'wifi'], False),
    ('seq_fraction', ['seq'], 0.5),
    ('bad_node_id', ['node_id'], 'bad:id'),
]:
    check(name, lambda p=path, v=value: decode(changed(base, p, v)), 'reject')
check('unknown_link_field', lambda: decode(changed(base, ['payload', 'link'], 'wifi')), 'reject')
check('duplicate_json_key', lambda: decode(json.dumps(base).replace('"seq": 0', '"seq": 0, "seq": 1')), 'reject')
for name, path, value in [
    ('millis_as_utc', ['payload', 'sample_ms'], 1000),
    ('invalid_zero_instead_null', ['payload', 'value'], 0),
    ('sample_ms_fraction', ['payload', 'sample_ms'], NOW + 0.5),
    ('future_beyond_skew', ['payload', 'sample_ms'], NOW + 2001),
]:
    check(name, lambda p=path, v=value: ingest_pair(changed(fresh, p, v)), 'reject')
no_value = copy.deepcopy(fresh)
del no_value['payload']['value']
check('missing_value', lambda: decode(no_value), 'reject')
check('reading_before_hello', lambda: SwarmCoordinator('lab').ingest(valid, now_ms=NOW), 'reject')
check('valid_with_wrong_status', lambda: ingest_pair(changed(valid, ['payload', 'status'], 'not_ready')), 'reject')


def processing_changes():
    s = SwarmCoordinator('lab')
    s.ingest(base, now_ms=NOW)
    s.ingest(valid, now_ms=NOW)
    second = copy.deepcopy(valid)
    second['seq'] = 2
    second['payload']['processing_version'] = 'cts-2'
    second['payload']['sample_ms'] = NOW + 1
    return s.ingest(second, now_ms=NOW + 1)


check('processing_version_can_change_within_boot', processing_changes)


def typed(kind, value, extras):
    h = copy.deepcopy(base)
    d = h['payload']['channels']['temp']['descriptor']
    d.update(value_type=kind, **extras)
    s = SwarmCoordinator('lab')
    s.ingest(h, now_ms=NOW)
    r = copy.deepcopy(valid)
    r['payload']['value'] = value
    return s.ingest(r, now_ms=NOW)


check('vector_three_axes', lambda: typed('vector', [0, 1, 2], {'axes': ['x', 'y', 'z']}))
check('waveform_window', lambda: typed('waveform', [0, 1, 2], {'length': 3, 'sample_period_us': 1000}))
check('boolean_value', lambda: typed('boolean', False, {}))
check('category_value', lambda: typed('category', 'clear', {}))
huge = copy.deepcopy(base)
d = huge['payload']['channels']['temp']['descriptor']
d['normalization'] = {'method': 'table', 'output_unit': 'degC', 'evidence_id': 'bench',
                      'knots': [[i * 10000000000, i * 10000000000] for i in range(64)]}
d['vendor'] = 'V' * 96
d['device_model'] = 'D' * 96
d['model_id'] = 'M' * 96
d['coordinate_frame'] = 'C' * 96
huge['payload']['channels'] = {f'ch{i}': copy.deepcopy(huge['payload']['channels']['temp']) for i in range(32)}
check('32_channels_64_knots_exceeds_wire_limit', lambda: decode(huge), 'reject')
out = {'scope': 'host parser and coordinator only; no firmware or hardware execution',
       'wire_limit_fixture_bytes': len(json.dumps(huge, separators=(',', ':')).encode()),
       'checks': results, 'passed': sum(r['passed'] for r in results), 'total': len(results)}
print(json.dumps(out, indent=2, ensure_ascii=False))
raise SystemExit(0 if all(r['passed'] for r in results) else 1)
