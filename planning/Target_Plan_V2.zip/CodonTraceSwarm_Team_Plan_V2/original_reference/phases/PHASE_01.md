# فاز ۱ — هستهٔ پروتکل

## هدف

ساختن hello و reading و heartbeat نسخهٔ ۲ روی `Client&`، با ساعت UTC و MQTT 3.1.1. بدون رجیستری غنی، بدون درایور، بدون حلقهٔ فرمان.

## فایل‌های مجاز

`library.properties` هنوز نه. فقط:

- `src/CodonTraceSwarm.h` اعلان نازک
- `src/cts/Wire.h` و `Wire.cpp` ساخت JSON
- `src/cts/Clock.h` درگاه ساعت. پیاده‌سازی پیش‌فرض ESP32 با `configTime` و `gettimeofday`. برد دیگر در این فاز فقط اینترفیس را می‌بیند
- `src/cts/MqttSession.h` و `.cpp` وصل شدن با arduino-mqtt 2.5.3، QoS 1، retain false
- `examples/BasicWiFi/BasicWiFi.ino` یک کانال اسکالر ثابت، نه یک حسگر واقعی
- `test/host_ingest.py` که JSON تولیدشده را به `decode` و `ingest` ریپو می‌دهد. این آزمون روی رایانه است نه روی برد

## ممنوع

درایور، `define()` کامل، تبلیغ `sample`، سریال، `WiFi.h` داخل `Wire.*`، تغییر ریپوی پایتون، `firmware/esp32`.

## رفتار hello

`operations` برابر `[]`. یک کانال اسکالر direct با واحد برابر source_unit. `wifi:true` به‌خاطر پرچم سازگاری. توضیح کنار پرچم اجباری است.

## خروج

1. ingest میزبان hello را می‌پذیرد.
2. reading معتبر بعدی با `sample_ms` داخل پنجره پذیرفته می‌شود و مقدارش صفرِ ساختگی نیست.
3. reading با `valid:false` و `value:null` پذیرفته می‌شود و به‌صورت عدد ذخیره نمی‌شود.
4. retain، reading قبل از hello، `wifi:1`، و `sample_ms` اعشاری رد می‌شوند.
5. هیچ فایلی از فاز ۲ و ۳ در درخت نیست.

تستر این پنج بند را با `test/host_ingest.py` و ریپوی `74c7b3f` یا جدیدتر نشان می‌دهد.
