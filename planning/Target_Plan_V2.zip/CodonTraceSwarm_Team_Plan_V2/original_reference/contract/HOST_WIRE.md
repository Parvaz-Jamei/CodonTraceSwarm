# قرارداد سیم — codontrace-genesis @ 74c7b3f

منبع داور، به این ترتیب: `src/codontrace/swarm/protocol.py`، `src/codontrace/contracts/channels.py`، `src/codontrace/contracts/wire_validation.py`، `src/codontrace/swarm/runtime.py`، `src/codontrace/swarm/mqtt.py`. این متن خلاصه است. اگر با فایل فرق داشت، فایل برنده است.

## پوشه

بافر حداکثر ۶۵۵۳۶ بایت. پیام شیئی با دقیقاً این کلیدها:

`schema`, `swarm_id`, `node_id`, `boot_id`, `seq`, `kind`, `payload`

`schema` فقط `genesis_swarm_v2` برای این کتابخانه. `seq` عدد صحیح نامنفی. شناسه‌ها الگوی `IDENTIFIER_PATTERN` در `wire_validation.py`.

`kind`: `hello` | `reading` | `heartbeat` | `reply`.

## hello

payload دقیقاً `wifi`, `channels`, `operations`.

- `wifi` باید بولین `true` باشد وگرنه `Wi-Fi node required` (`protocol.py` حدود خط ۵۵). false حتی برای اترنت امروز رد می‌شود. فیلد `link` کلید ناشناخته است و رد می‌شود.
- ۱ تا ۳۲ کانال. نام کانال شناسه است.
- هر کانال v2 دقیقاً `quantity`, `unit`, `descriptor`. هر دو متن حداکثر ۹۶ و غیرخالی.
- واحد کانال باید برابر `normalization.output_unit` باشد اگر نرمال‌سازی هست، وگرنه برابر `source_unit`. پیام خطا: `channel requires explicit unit normalization`.
- `operations` زیرمجموعهٔ بدون تکرارِ `sample`, `raw`, `features`, `result`, `set_rate`, `pipeline`, `capsule`. آرایهٔ خالی قانونی است.

## descriptor

الزامی: `value_type`, `measurement_model`, `feature_id`, `config_id`, `source_unit`.

`value_type`: scalar | vector | waveform | boolean | category

`measurement_model`: direct | derived | proxy | raw

- derived و proxy بدون `model_id` رد می‌شوند. `model_id` متن است نه لزوماً شناسه. حداکثر ۹۶.
- `feature_id` و `config_id` و نام محور و `evidence_id` شناسه‌اند.
- vector: `axes` یک تا ۱۶ شناسهٔ یکتا. waveform: `length` از ۱ تا ۲۵۶.
- `sample_period_us` اختیاری است و فقط روی waveform، از ۱ تا ۳۶۰۰۰۰۰۰۰۰. این کتابخانه برای waveform آن را اجباری می‌کند تا پایهٔ زمان بعداً اختراع نشود. این سخت‌گیری کتابخانه است نه میزبان.
- `rate_hz` جفت `[lo, hi]` با `0 < lo <= hi <= 10000`. اگر نباشد، میزبان برای `set_rate` بازهٔ ۰٫۰۱ تا ۱۰۰۰۰ را می‌پذیرد. پس تبلیغ `set_rate` بدون سقف روی هر کانال ممنوع است.
- نرمال‌سازی عددی فقط affine یا table. affine: scale غیرصفر، offset، output_unit، evidence_id. table: ۲ تا ۶۴ گره، x اکیداً صعودی، بدون برون‌یابی. تنها evidence آماده: `SI-prefix` با مقیاس `1e-12` از pF به F، همان `adapters/fdc.py`.
- دستگاه مقدار را در `source_unit` می‌فرستد.

## reading

الزامی v2: `channel`, `sample_ms`, `value`, `processing_version`, `valid`, `status`, `config_id`.

- `sample_ms` میلی‌ثانیهٔ UTC، صحیح. پیش‌فرض میزبان: skew دو ثانیه، ttl ده ثانیه (`runtime.py`). خارج از آن: `stale sample or clock skew`.
- نامعتبر: `valid:false` و `value:null`. معتبر: `valid:true` و `status` دقیقاً `ok` و مقدار با شکل descriptor.
- `config_id` نمونه باید با توصیفگر یکی باشد.
- اختیاری: `raw` (۱..۲۵۶ عدد)، `features` (حداکثر ۳۲)، `quality` در [۰،۱] که عدم‌قطعیت VIM نیست، `metadata` حداکثر ۳۲ کلید شناسه با مقدار عدد یا بولین یا null یا متن تا ۲۵۶، `uncertainty`, `source_unit`, `reference_unit`, `reference` همراه `reference_id`, `energy_j` در [۰، ۱e6].
- این کتابخانه در فاز ۱ تا ۵ فیلد `energy_j` و `quality` و `uncertainty` را نمی‌فرستد.

reading قبل از hello همان boot رد می‌شود: `hello required for this boot session` (`runtime.py` حدود خط ۱۰۷).

## heartbeat و reply

heartbeat: payload دقیقاً `{}`.

reply: `command_id`, `ok` بولین، و اختیاری `message` تا ۲۵۶. `command_id` میزبان شکل `cmd-N` دارد و شناسهٔ قانونی است. پاسخ به فرمان غیر pending رد می‌شود. PUBACK اجرای فرمان نیست.

## فرمان پایین

موضوع `genesis/swarm/{swarm_id}/{node_id}/down`. بدنهٔ تولیدشده در `runtime.py`:

`schema=genesis_swarm_command_v1`, `swarm_id`, `node_id`, `boot_id`, `command_id`, `operation`, `params`, `created_ms`, `expires_ms`, `status=pending`.

پارامترها: برای sample و raw و features و result فقط `channel`. برای set_rate همچنین `hz`. برای pipeline و capsule همچنین `pipeline` و اختیاری `source_digest`. عملگر دیگری وجود ندارد. رله فرمان نیست.

## MQTT میزبان

`mqtt.py`: پورت پیش‌فرض ۸۸۸۳، `tls_set`، subscribe به `genesis/swarm/{id}/+/up` با QoS 1، publish فرمان retain=false. پیام retained رد می‌شود. کلاینت میزبان MQTT 5 است (paho). دستگاه با arduino-mqtt روی 3.1.1 حرف می‌زند. بروکر باید هر دو را بپذیرد. این کتابخانه MQTT 5 پیاده نمی‌کند.

## زمان و بوت

اولین پیام هر `boot_id` باید hello باشد. در همان boot، کانال‌ها و operations عوض نمی‌شوند. `boot_id` تکراری با seq از نو، نشست جدید نیست. `processing_version` در طول boot ثابت است. heartbeat حدود هر ۵ ثانیه لازم است تا ttl ده ثانیه گره را مرده نبیند.

## FDC

FDC1004: مقدار سیم پیکوفاراد، واحد کانال `F`، source_unit برابر `pF`، affine بالا. صفر پیکوفاراد مقدار قانونی است. خطا null است.

FDC2214: مقدار هرتز، derived، `model_id` برابر `FDC2x1x-reference-clock`. این پیکوفاراد نیست. FDC211x در نسخهٔ 0.6.13 پشتیبانی تبدیل فرکانس ندارد و نباید کانال معتبر بسازد.
