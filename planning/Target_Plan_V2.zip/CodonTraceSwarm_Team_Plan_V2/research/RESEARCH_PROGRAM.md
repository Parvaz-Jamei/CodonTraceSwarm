# چهار ایدهٔ پژوهشی قابل‌آزمون، متناسب با موتور

## نقشهٔ سابقه و ادعای مجاز

| ایده | جزء شناخته‌شده | تفاوت پیشنهادی این پروژه | وضعیت فعلی |
|---|---|---|---|
| RQ-S1 نمونه‌برداری تطبیقی | adaptive sensing، conformal، مدل هزینه | تخصیص نرخ با QD رفتاری و مترولوژی و provenance و replay واحد | فرضیهٔ ترکیبی، نه اولین‌بودن اثبات‌شده |
| RQ-S2 خطای مشترک | reference calibration، sensor fusion، causal intervention | تصمیم برای گرفتن مرجع/تغییر شرایط همراه حفظ missingness و ساعت | نیازمند bench و identification |
| RQ-S3 انتقال سیاست | domain shift، transfer learning، shadow deployment | انتخاب سیاست میان انواع/واحدهای صریح، آزمون عدم انتقال و rollback ثبت‌شده | تجربهٔ مهندسی متمایز؛ الگوریتم جدید باید جدا ثابت شود |
| RQ-S4 تنوع مقاوم | MAP-Elites noisy/adaptive sampling | archive رفتار برای dropout/clock/sensor faults و adversarial scenarios held-out | پایه قدیمی؛ ترکیب و ارزیابی پیشنهادی |

چهار نام صرفاً شناسهٔ داخلی‌اند و Red Queen زیستی نیستند. موتور به یک فرضیه محدود نمی‌شود. این آزمایش‌ها را با ادعای Red Queen یکی نکنید؛ noise attack روی سنسور به‌تنهایی میزبان–انگل هم‌فرگشتی نیست.

### RQ-S1 — نرخ تطبیقی با کیفیت قابل سنجش

پرسش: آیا سیاست‌های حاصل از QD تحت budget برابر، event recall و delay را نسبت به fixed-rate، threshold و uncertainty-only بهتر نگه می‌دارند؟

محیط: waveform یا scalar فیزیکی با مرجع مستقل و event labels. baseline fixed-rate چند نرخ، threshold ساده، EWMA/innovation scheduler، uncertainty-only و random-rate با هزینهٔ matched. Genesis روی نرخ‌ها و قواعد bounded جست‌وجو می‌کند؛ هر نامزد روی episodeهای training ارزیابی؛ calibration و test زمانی/دستگاهی جدا. predictive interval دربارهٔ y مشخص با reference label، نه quality حسگر.

سنجهٔ اصلی از پیش انتخاب شود: مثلاً recall با false alarms/hour و detection delay تحت سقف bytes یا samples؛ معیار engineering margin پیش از دیدن test تعیین شود. measured joules فقط با supply metering واقعی؛ اگر ندارید bytes/samples معیار هزینه است و نام انرژی نگیرد. age-of-information با timestamp واقعی و clock-error band، نه latency از زمان publish.

کنترل: خطی ثابت بدون event، event کاشته‌شده با ground truth، null effect، random-label، dropout burst، aliasing frequency، shift دما/روز/برد. هیچ future residual در سیاست online استفاده نشود. split conformal تحت exchangeability، در drift تضمین همان finite-sample را ادعا نکنید؛ coverage rolling، interval width و delay labels و مفروضات ACI گزارش شود. Bayesian/GP سبک هم baseline optional است، نه وابستگی اجباری firmware.

مراحل این ایده حداکثر۵: ۱) مرور نزدیک‌ترین روش و prereg، ۲) calibration instrumentation، ۳) development و search، ۴) held-out و bench، ۵) تحلیل/ablation و artifact. در هر مرحله چرخهٔ تیم اجرا شود.

### RQ-S2 — تشخیص مشترک‌خطا با مرجع و مداخله

پرسش: توافق چند سنسور واقعاً درست‌بودن را نشان می‌دهد؟ خیر، خطای مشترک می‌تواند همه را هم‌جهت ببرد. آزمایش باید بسنجد آیا انتخاب مرجع مستقل و مداخلهٔ از پیش تعریف‌شده shared bias را بهتر از consensus-only آشکار می‌کند.

نمونهٔ FDC: ۳ electrode/channel یا چند برد، reference capacitors معلوم و دماسنج، nuisance تغذیه/دما/کابل. reference باید مسیر وابستگی مستقل داشته باشد؛ دو کانال یک IC یا یک supply مستقل محسوب نمی‌شوند. آزمایش reference/no-reference و consensus/robust median/reference-assisted؛ sensor fault مستقل و common-mode، تغییر واقعی measurand و measurement artifact جدا.

سنجه: bias نسبت مرجع، fault detection precision/recall، false alarm، time-to-detection، calibration interval؛ calibration fit فقط training/reference stage. مداخلهٔ پیکربندی یا sample rate با عملیات قانونی میزبان؛ تغییر فیزیکی منبع/کابل اگر لازم است توسط operator آزمایش، firmware عملگر غیرمجاز نسازد. causal claim تنها با assignment و فرض‌های identification روشن؛ observed correlation را causal labeling نکنید.

پنج مرحله: طراحی DAG وابستگی، calibrate reference، اجرای random-order مداخلات، held-out confounder challenge، تحلیل identifiability و شکست‌ها. اگر بدون reference قابل شناسایی نیست، نتیجهٔ «شناساپذیر نیست» ارزشمند و باید همان گزارش شود.

### RQ-S3 — انتقال سبک و قابل رد بین بردها

پرسش: آیا انتقال policy با typed feature/unit contract و gate مبتنی بر reference، negative transfer را نسبت به blind-copy کاهش می‌دهد؟

policy اولیه EWMA/clip/event_threshold میزبان فعلی، نه NN مبهم؛ مدل درخت خطی/کوچک آینده با extension مدل. hold-one-device یا sensor family out، training دستگاه A و test دستگاه B؛ scale و sample-rate mismatch، saturation، drift و different noise spectra جدا. فقط SI-conversion مجاز؛ countهای سنسورهای متفاوت بدون reference به هم تبدیل نشوند.

baseline no-transfer، blind-copy، target-only با بودجهٔ matched، gated-transfer. shadow ابتدا بدون تغییر مسیر اصلی؛ ارزیابی روی پنجرهٔ بعدی با مرجع، نه نمونه‌های انتخاب policy. هر update اثر parameter، version، expiry، reply و rollback تصمیمی را journal کند. در نبود مرجع independent، «بهترشدن accuracy» قابل ادعا نیست؛ فقط resource/runtime behavior گزارش شود.

سنجهٔ اصلی negative-transfer rate با تعریف margin، error/event recall، latency و byte budget؛ randomization به دستگاه/episode، نه هر sample هم‌بسته. پنج مرحله: descriptor compatibility، source training، shadow held-out، فعال‌سازی محدود و rollback test، تحلیل تعمیم.

### RQ-S4 — آرشیو تنوع رفتار برای شرایط خراب

پرسش: آیا آرشیو چند سیاست با رفتار متفاوت در برابر fault جدید از یک بهترین سیاستِ training مقاوم‌تر است؟

نامزدها از QD موجود موتور؛ novelty descriptor latency/recall/resource/recovery واقعی. disturbance generator شبیه‌سازی شده با RNGManager/manifest؛ sensor noise حقیقی log شده. شرایط held-out شامل missing bursts، jitter/time offset، independent/shared bias و drift؛ اگر generator و policy هم‌تکاملی دارند، population/update/fitness هر دو و کنترل frozen/random disturbance لازم است. بهینه‌سازی در برابر بدترین noise ساختهٔ تیم به‌تنهایی کشف ALife نیست.

baseline best-single، random-search همان بودجه، MAP-Elites پارامتری برای ablation، behavior-QD و minimax ساده. هر elite با چند episode تازه بازسنجی شود تا lucky winner حذف شود؛ archive score روی test بهینه‌سازی نشود. سنجه worst-case regret/recovery، diversity واقعی و archive coverage؛ ثابت شدن سنجهٔ diversity روی grid نشانگر تنوع علمی نیست.

پنج مرحله: طراحی رفتار و budget، کنترل instrument و search parity، frozen challenge development، unseen challenge/board، ablation و تجزیهٔ هزینه.

## برنامهٔ آماری مشترک

در pilot سبک ۸ seed شبیه‌سازی برای عیب‌یابی؛ confirmatory count از precision/power هدف و pilot جدا تعیین شود، عدد۲۴ یا۳۲ قانون جادویی نیست. CPU deadline و event count و length برحسب process time scale تعیین شود. از sampleهای یک stream CI مستقل نسازید؛ paired episode/device effects و bootstrap بلوکی یا cluster-level با گزارش تعداد cluster و block-length sensitivity. repeated peeking برای انتخاب پایان موفق ممنوع؛ اگر sequential لازم است stopping rule/e-value/alpha spending از پیش مشخص شود. چند primary endpoint/چهار ایده نیاز به multiplicity plan دارند. effect size و CI و عملی‌بودن margin همراه p، outcome inconclusive مجاز.

هیچ‌وقت اثر ساختگی positive control را به‌عنوان نتیجهٔ مکانیزم گزارش نکنید. کنترل مثبت فقط توان ابزار را می‌سنجد. `PASS engineering` و `SUPPORTED hypothesis` دو محور جدا هستند. حد منابع آزمایش بر board، افت شبکه و throttling ثبت شود؛ سرعت Orange Pi به‌تنهایی novelty الگوریتم نیست، resource-normalized benchmark لازم است.

## قانون سرچ و تازگی

قبل از هر مرحله query، تاریخ، primary source، nearest methods، تفاوت، و حدود ادعا ثبت شود. سرچ مجدد در آغاز prereg و پیش از نوشتن مقاله انجام شود. دسته‌های جست‌وجو: adaptive sensor scheduling/QD، sensor fault identifiability/common mode، conformal dependent series، cross-device transfer/calibration، noisy QD. اگر تفاوت روشن نشد، روی benchmark قابل بازتولید و مهندسی مفید تمرکز و ادعای کشف کاهش یابد. ترکیب میان‌رشته‌ای به معنی کنار هم چیدن نام‌ها نیست؛ هر جزء باید ablation مستقل و معیار اثر داشته باشد.
