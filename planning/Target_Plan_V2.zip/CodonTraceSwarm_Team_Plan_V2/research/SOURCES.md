# منابع اولیه و اثرشان بر طراحی

بازبینی اینترنت: ۲۰۲۶-۱۰-۱۲. لینک‌های جاری مستندات در ساخت بعدی باید با tag/SHA یا نسخهٔ document ثبت شوند؛ latest pin نیست.

| منبع | کاربرد محدود و دقیق |
|---|---|
| [MQTT3.1.1 OASIS](https://docs.oasis-open.org/mqtt/mqtt/v3.1.1/os/mqtt-v3.1.1-os.html) | QoS1 duplicate؛ delivery guarantee با اثر فرمان فرق دارد |
| [256dpi arduino-mqtt](https://github.com/256dpi/arduino-mqtt) | بافر دریافت، advanced callback، جلوگیری از publish از callback، API Client؛ نسخه2.5.3 ورودی را کورکورانه latest فرض نکنید |
| [ArduinoJson upgrade](https://arduinojson.org/v7/upgrade-from-v6/) و [allocator](https://arduinojson.org/v7/api/jsondocument/) | تفاوت heap/stack و انتخاب allocator محدود، بدون وعدهٔ غیرواقعی zero-allocation |
| [ESP32 Ethernet](https://docs.espressif.com/projects/arduino-esp32/en/latest/api/ethernet.html) و [NetworkClientSecure](https://github.com/espressif/arduino-esp32/blob/master/libraries/NetworkClientSecure/src/NetworkClientSecure.h) | تفاوت underlying transport و secure client؛ نمونهٔ ETH+TLS باید واقعی compile/bench شود |
| [ESP32 system time](https://docs.espressif.com/projects/esp-idf/en/stable/esp32/api-reference/system/system_time.html) | SNTP، smooth/step و drift ساعت؛ clock readiness در metadata و test |
| [RFC8428 SenML](https://www.rfc-editor.org/rfc/rfc8428.html) و [RFC8798 units](https://www.rfc-editor.org/rfc/rfc8798.html) | الهام metadata/unit/time و bridge آینده؛ پروتکل Genesis SenML-compliant اعلام نشود |
| [VIM](https://jcgm.bipm.org/vim/en/index.html) و [GUM6 measurement models](https://www.bipm.org/documents/20126/2071204/JCGM_GUM_6_2020.pdf) | مدل اندازه‌گیری و فرق quality و measurement uncertainty |
| [TI FDC1004 datasheet](https://www.ti.com/lit/ds/symlink/fdc1004.pdf) | output/CAPDAC/config واقعی؛ driver API با datasheet یکی نیست |
| [Adaptive Conformal Inference, Gibbs & Candès, NeurIPS2021](https://proceedings.neurips.cc/paper/2021/hash/0d441de75945e5acbc865406fc9a2559-Abstract.html) | online coverage frequency در شرایط مقاله؛ تضمین شرطی لحظه‌ای برای هر sensor نتیجه نمی‌شود |
| [Multi-Source Conformal Inference, ICML2024](https://proceedings.mlr.press/v235/liu24ag.html) | سابقهٔ source shift و weighting؛ انتقال آن به سنسور نیاز به فرض و reference دارد |
| [MAP-Elites noisy/adaptive sampling, GECCO2019](https://researcher.itu.dk/p/en/research-outputs/map-elites-for-noisy-domains-by-adaptive-sampling) | QD تحت noise قدیمی است؛ بازسنجی elite و adaptive evaluation جزء baseline |
| [VQ-Elites2025](https://arxiv.org/html/2504.08057v1) | سابقهٔ behavioral archive آموخته‌شده؛ استفادهٔ سادهٔ QD نوآوری منحصر نیست |

پیش‌چاپ و مقالهٔ داوری‌شده در log برچسب متفاوت داشته باشند. هیچ ادعای اینکه جست‌وجو جامع کل علم است وجود ندارد. مستندات فنی منابع روش‌اند، شاهد برتری این محصول نیستند.
